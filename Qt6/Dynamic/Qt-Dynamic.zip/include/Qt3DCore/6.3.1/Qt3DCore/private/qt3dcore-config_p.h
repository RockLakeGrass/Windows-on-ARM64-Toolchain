#define QT_FEATURE_qt3d_assimp 1

#define QT_FEATURE_qt3d_system_assimp -1

#define QT_FEATURE_qt3d_simd_sse2 -1

#define QT_FEATURE_qt3d_simd_avx2 -1

